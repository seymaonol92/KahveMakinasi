package School_Project_Task.src;

import java.util.ArrayList;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class OgretmenManager extends Veritabani {

    static Scanner scan = new Scanner(System.in);

    public static void ogretmenMenu() throws InterruptedException {

        // TODO ogretmenMenu() methodundaki eksiklikleri tamamlayiniz

        String secim;

        do {
            System.out.println(
                    "\n============= TECHNO STUDY BOOTCAMP =============\n" +
                            "================= OGRETMEN MENU =================\n" +
                            "\n" +
                            "\t   1- Ogretmenler Listesi Yazdir\t\n" +
                            "\t   2- Soyisimden Ogretmen Bulma\n" +
                            "\t   3- Branstan Ogretmen Bulma\n" +
                            "\t   4- Bilgilerini Girerek Ogretmen Ekleme\n" +
                            "\t   5- Kimlik No Ile Kayit Silme \t\n" +
                            "\t   A- ANAMENU\n" +
                            "\t   Q- CIKIS\n");


            secim = scan.nextLine().toLowerCase();

            switch (secim) {
                case "1":
                    ogretmenListesiYazdir();
                    break;
                case "2":
                    soyisimdenOgretmenBulma();
                    break;
                case "3":
                    branstanOgretmenBulma();
                    break;
                case "4":
                    ogretmenEkleme();
                    break;
                case "5":
                    tcNoIleOgretmenSil();
                    break;
                case "a":
                    Helper.anaMenu();
                    break;
                default:
                    System.out.println("Lütfen geçerli seçim yapınız");
            }
        } while (!secim.equalsIgnoreCase("q"));
        Helper.projeDurdur();
    }


    public static void tcNoIleOgretmenSil() throws InterruptedException {
        System.out.println("Silinecek ogretmen kimlik no giriniz");
        String silinecekOgretmen = scan.nextLine();

        String silinecekValue = ogretmenlerMap.get(silinecekOgretmen);
        String sonucValue = ogretmenlerMap.remove(silinecekOgretmen);

        System.out.print(silinecekOgretmen + " Siliniyor...");
        for (int i = 0; i < 20; i++) {
            Thread.sleep(100);
            System.out.print(">");
        }

        //////////////////////////////////////////////////////////////////////////////
        // BU BLOĞU DEĞİŞTİRMEYİN, DİKKATE ALMAYIN...                               //
        // SİLİNECEK KİMLİK NO YOKSA VEYA BAŞKA BEKLENMEDİK                         //
        // ŞEYLER OLURSA KODUN DEVAMINI SAĞLAYACAK...
        try {                                                                       //
            boolean sonuc = sonucValue.equals(silinecekValue);                      //
        } catch (Exception e) {                                                     //
            System.out.println("Istediginiz Tc numarasi ile ogretmen bulunamadi");  //
        }                                                                           //
        //////////////////////////////////////////////////////////////////////////////
    }

    /// ////////////////////////////////////////////////////////////

    // TODO ogretmenEkleme() methodunu doldurunuz
    public static void ogretmenEkleme() {

        System.out.println("TC numaranızı giriniz: ");
        String tcNo = scan.nextLine();

        System.out.println("İsminizi giriniz: ");
        String isim = scan.nextLine();

        System.out.println("Soyisminizi giriniz: ");
        String soyisim = scan.nextLine();

        System.out.println("Doğum yılınız: ");
        String dogumYili = scan.nextLine();

        System.out.println("Branşınız: ");
        String brans = scan.nextLine();

        ArrayList<String> bilgiler = new ArrayList<>();
        bilgiler.add(isim);
        bilgiler.add(soyisim);
        bilgiler.add(dogumYili);
        bilgiler.add(brans);

        ogretmenlerMap.put(tcNo, String.valueOf(bilgiler));

        System.out.println("Öğretmen eklenmesi yapıldı.");


    }

    // TODO Bu methodu degistirmeyiniz.
    public static void branstanOgretmenBulma() throws InterruptedException {
        System.out.println("Aradiginiz Ogretmenin Bransini Giriniz:");
        String istenenBrans = scan.nextLine();

        System.out.print(istenenBrans + " Ogretmenleri Listeleniyor...");
        for (int i = 0; i < 20; i++) {
            Thread.sleep(100);
            System.out.print(">");
        }

        Set<Map.Entry<String, String>> ogretmenEntrySet = ogretmenlerMap.entrySet();
        System.out.println(
                "\n============= TECHNO STUDY BOOTCAMP =============\n" +
                        "============BRANS ILE OGRETMEN ARAMA ============\n" +
                        "TcNo : Isim , Soyisim , D.Yili , Brans");

        // Daha düzgün bi görünüm için printf veya String.format kullanılabilir... İsteğe bağlı
        for (Map.Entry<String, String> each : ogretmenEntrySet) {
            String eachKey = each.getKey();
            String eachValue = each.getValue();

            String[] eachValuarr = eachValue.split(", ");
            if (istenenBrans.equalsIgnoreCase(eachValuarr[3])) {
                System.out.println(eachKey + " : " + eachValue + " | ");
            }
        }
    }

    /// ////////////////////////////////////////////////////////////

    // TODO soyisimdenOgretmenBulma() methodunu doldurunuz
    public static void soyisimdenOgretmenBulma() throws InterruptedException {

        System.out.println("Aranan öğretmenin soyismini giriniz: ");
        String soyad = scan.nextLine();

        boolean soyadBulundu = false;
        for (Map.Entry<String, String> entry : ogretmenlerMap.entrySet()) {
            String deger = entry.getValue();
            if (deger.toLowerCase().contains(soyad.toLowerCase())) {

                System.out.println(entry.getKey() + " : " + deger);
                soyadBulundu = true;
            } else {
                System.out.println("Girilen değerde soyisim bulunamadı.");
            }
        }

    }

    /// ////////////////////////////////////////////////////////////

    // TODO ogretmenListesiYazdir() methodunu doldurunuz
    public static void ogretmenListesiYazdir() throws InterruptedException {

        System.out.println(" ------- Öğretmen Listesi -------");

        for (Map.Entry<String, String> entry : ogretmenlerMap.entrySet()) {
            System.out.println(entry.getKey() + " : " + entry.getValue());
        }


    }
}



