package School_Project_Task.src;

import java.lang.management.ManagementPermission;
import java.util.ArrayList;
import java.util.Map;
import java.util.Scanner;

public class OgrenciManager extends Veritabani {

    static Scanner scan = new Scanner(System.in);

    public static void ogrenciMenu() throws InterruptedException {

          String secim;
      do  {
            System.out.println(
                    "\n============= TECHNO STUDY BOOTCAMP =============\n" +
                            "================== OGRENCI MENU =================\n" +
                            "\t   1- Ogrenci Listesi Yazdir\n" +
                            "\t   2- Soyisimden Ogrenci Bulma\n" +
                            "\t   3- Sinif ve Sube Ile Ogrenci Bulma\n" +
                            "\t   4- Bilgilerini Girerek Ogrenci Ekleme\n" +
                            "\t   5- Kimlik No Ile Kayit Silme \t\n" +
                            "\t   A- ANAMENU\n" +
                            "\t   Q- CIKIS");

            secim = scan.nextLine();

            switch (secim) {
                case "1" : ogrenciListeYazdir();
                break;
                case "2": soyisimdenOgrenciBulma();
                break;
                case "3" : sinifVeSubeIleOgrenciBulma();
                break;
                case "4" : ogrenciEkle();
                break;
                case "5" : tcNoIleOgrenciSilme();
                break;
                case "a" : Helper.anaMenu();
                default:
                    System.out.println("Lütfen geçerli seçim yapınız");
            }

        }while (!secim.equalsIgnoreCase("q"));
        Helper.projeDurdur();
    }

    private static void tcNoIleOgrenciSilme() throws InterruptedException {
        System.out.println("Silinecek ogrenci kimlik no giriniz");
        String silinecekOgrenci = scan.nextLine();

        String silinecekValue = ogrenciMap.get(silinecekOgrenci);
        String sonucValue = ogrenciMap.remove(silinecekOgrenci);

        System.out.print(silinecekOgrenci + "Siliniyor...");
        for (int i = 0; i < 20; i++) {
            Thread.sleep(100);
            System.out.print(">");
        }
        //  Programın çalışmaya devam etmesi için gerekli
        try {
            boolean sonuc = sonucValue.equals(silinecekValue);
        } catch (Exception e) {
            System.out.println("Istediginiz TC numarasi ile ogrenci bulunamadi");
        }

    }


    // TODO ogrenciEkle() methodunu doldurunuz
    private static void ogrenciEkle() {
        System.out.println("TC kimlik numarası giriniz: ");
        String tcNoOgrenci = scan.nextLine();

        System.out.print("İsminizi giriniz: ");
        String isim = scan.nextLine();

        System.out.print("Soyisminizi giriniz: ");
        String soyad = scan.nextLine();

        System.out.println("Okul numaranızı giriniz: ");
        String okulNo = scan.nextLine();

        System.out.print("Doğum yılınızı giriniz: ");
        String dogumYili = scan.nextLine();

        System.out.print("Sınıf: ");
        String sinif = scan.nextLine();
        System.out.println("Şube: ");
        String sube = scan.nextLine();

        ArrayList<String> ogrenciBilgiler = new ArrayList<>();
        ogrenciBilgiler.add(isim);
        ogrenciBilgiler.add(soyad);
        ogrenciBilgiler.add(okulNo);
        ogrenciBilgiler.add(dogumYili);
        ogrenciBilgiler.add(sinif);
        ogrenciBilgiler.add(sube);

        ogrenciMap.put(tcNoOgrenci, String.valueOf(ogrenciBilgiler));

        System.out.println("Yeni öğrenci başarıyla eklendi.");



    }

    ///////////////////////////////////////////////////////////////////////////////////

    // TODO sinifVeSubeIleOgrenciBulma() methodunu doldurunuz
    // OgretmenManager classindaki branstanOgretmenBulma() methodundan faydalanabilirsiniz
    private static void sinifVeSubeIleOgrenciBulma() throws InterruptedException {

        System.out.println("Sınıf giriniz: ");
        String sinif = scan.nextLine();

        System.out.println("Şube giriniz: ");
        String sube = scan.nextLine();

        System.out.println(sinif + " sınıfı" + sube + "şubesi öğrencileri listeleniyor..");

        boolean ogrenciVarMi = false;
        for (Map.Entry<String, String> entry : ogrenciMap.entrySet()) {

            String entryKey = entry.getKey();
            String entryValue = entry.getValue();


            String [] entryValuarr = entryValue.split(", ");
            String sinifVal = entryValuarr[4].trim();
            String subeVal = entryValuarr[5].trim();

            if (sinif.equalsIgnoreCase(sinifVal) && sube.equalsIgnoreCase(subeVal)){
                System.out.println(entryKey + " : " + entryValue);
                ogrenciVarMi = true;
            } else {
                System.out.println("Öğrenci bulunamadı");
            }

        }
    }

    ///////////////////////////////////////////////////////////////////////////////////

    // TODO soyisimdenOgrenciBulma() methodunu doldurunuz

    private static void soyisimdenOgrenciBulma() throws InterruptedException {


        System.out.println("Aranan öğrencinin soyismini giriniz: ");
        String soyad = scan.nextLine();

        boolean soyadBulundu = false;

        for (Map.Entry<String, String> entry : ogrenciMap.entrySet()) {
            String deger = entry.getValue();
            if (deger.toLowerCase().contains(soyad.toLowerCase())) {

                System.out.println(entry.getKey() + " : " + deger);
                soyadBulundu = true;
            } else {
                System.out.println("Girilen değerde soyisim bulunamadı.");
            }
        }

    }

    ///////////////////////////////////////////////////////////////////////////////////

    // TODO ogrenciListeYazdir() methodunu doldurunuz
    private static void ogrenciListeYazdir() throws InterruptedException {

        System.out.println(" ------- Öğrenci Listesi -------");

        for (Map.Entry<String, String> entry : ogrenciMap.entrySet()) {
            System.out.println(entry.getKey() + " : " + entry.getValue());
        }

    }
}
