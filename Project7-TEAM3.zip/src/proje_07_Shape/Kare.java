package proje_07_Shape;

public class Kare implements IIslem {
    private double kenar;

    public Kare(double kenar) {
        this.kenar = kenar;
    }

    @Override
    public double alanHesapla() {
        return kenar*kenar;
    }

    @Override
    public double çevreHesapla() {
        return kenar*4 ;
    }


    // TODO Bu class doldurunuz.
}
