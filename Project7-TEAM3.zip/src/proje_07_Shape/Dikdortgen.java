package proje_07_Shape;

public class Dikdortgen implements IIslem {

    private double kısaKenar;
    private double uzunKenar;

    public Dikdortgen(double kısaKenar, double uzunKenar) {
        this.kısaKenar = kısaKenar;
        this.uzunKenar = uzunKenar;
    }




    @Override
    public double alanHesapla() {
        return uzunKenar*kısaKenar;
    }

    @Override
    public double çevreHesapla() {
        return (uzunKenar*2)+ (kısaKenar*2);
    }


    // TODO Bu class doldurunuz
}
