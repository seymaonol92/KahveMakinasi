package proje_07_Shape;

import java.util.Scanner;

public class Runner {
    public static void main(String[] args) {



        int seçim;


        while (true){

            Scanner scanner=new Scanner(System.in);

            System.out.println("--ANA MENÜ --");
            System.out.println("1. KARE ");
            System.out.println("2. DİKDÖRTGEN ");
            System.out.println("3. ÜÇGEN ");
            System.out.println("4. DAİRE ");
            System.out.println("0. ÇIKIŞ ");


            System.out.println("yapmak istediğiniz işlem için numara seçin: ");
            seçim=scanner.nextInt();



            switch (seçim){
                case 1:


                    System.out.print("kenar uzunluğu girin= ");
                    double kenarUzunluğu=scanner.nextDouble();
                    Kare kare = new Kare(kenarUzunluğu);

                    System.out.println("1. Alan");
                    System.out.println("2. çevre");
                    int kareİşlem=scanner.nextInt();

                    switch (kareİşlem){

                        case 1:
                            System.out.println("Alan : "+ kare.alanHesapla());
                            break;
                        case 2:
                            System.out.println("çevre = " + kare.çevreHesapla());
                            break;
                        default:
                            System.out.println("geçersiz işlem");

                    }  break;

                case 2:
                    System.out.println("kısa kenar uzunluğu");
                    double kısakenar= scanner.nextDouble();

                    System.out.println("uzun kenar uzunluğu");
                    double uzunKenar= scanner.nextDouble();

                    Dikdortgen dikdörtgen=new Dikdortgen(uzunKenar,kısakenar);

                    System.out.println("1.Alan ");
                    System.out.println("2. çevre ");
                    int dikdörtgenİşlem= scanner.nextInt();



                    switch (dikdörtgenİşlem){
                        case 1:
                            System.out.println("alan = " + dikdörtgen.alanHesapla());
                            break;
                        case 2:
                            System.out.println("çevre = " + dikdörtgen.çevreHesapla());
                            break;
                        default:
                            System.out.println("geçersiz işlem");
                    } break;

                case 3 :
                    System.out.print("1. kenar= ");
                    double kenar1= scanner.nextDouble();

                    System.out.print("2. kenar= ");
                    double kenar2= scanner.nextDouble();

                    System.out.print("3. kenar= ");
                    double kenar3= scanner.nextDouble();

                    Ucgen üçgen= new Ucgen(kenar1,kenar2,kenar3);

                    System.out.println("1.Alan ");
                    System.out.println("2. çevre ");
                    int üçgenİşlem= scanner.nextInt();

                    switch (üçgenİşlem){
                        case 1:
                            System.out.println(" alan = " + üçgen.alanHesapla());
                            break;
                        case 2:
                            System.out.println(" çevre = " + üçgen.çevreHesapla());
                            break;
                        default:
                            System.out.println("geçersiz işlem");
                    }break;

                case 4:
                    System.out.println("yarıçap= ");
                    double yarıÇap= scanner.nextDouble();

                    Daire daire= new Daire(yarıÇap);

                    System.out.println("1.Alan ");
                    System.out.println("2. çevre ");
                    int daireİşlem= scanner.nextInt();
                    switch (daireİşlem){
                        case 1:
                            System.out.println(" alan = " + daire.alanHesapla());
                            break;
                        case 2:
                            System.out.println(" çevre = " + daire.çevreHesapla());
                            break;
                        default:
                            System.out.println("geçersiz işlem ");
                    }break;

                case 0:
                    System.out.println("programdan çıkış yapılıyor....");
                    break;
            }



        }









    }
}
