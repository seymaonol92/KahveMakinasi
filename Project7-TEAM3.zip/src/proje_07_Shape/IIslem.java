package proje_07_Shape;

public interface IIslem {

    double alanHesapla();

    double çevreHesapla();

    // TODO Bu class doldurunuz
}
