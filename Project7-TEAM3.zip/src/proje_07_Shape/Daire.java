package proje_07_Shape;

public class Daire implements IIslem {
   private double r ;

    public Daire (double r ) {
        this.r = r;
    }

    @Override
    public double alanHesapla() {
        return Math.PI * r * r ;
    }

    @Override
    public double çevreHesapla() {
        return 2* Math.PI * r ;
    }


}
